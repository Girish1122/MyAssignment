var output =document.getElementById('result');// variable for getting the textbox input values
var resultvalue="";
var buttons =document.querySelectorAll('button'); //variable for getting button's input 

for(item of buttons) //iterating through the values of buttons
{
   item.addEventListener('click', (e)=> //making use of event listener method for recognizing the click activity
   {
    buttonContent=e.target.innerText;//taking the text of clicked button and matching with given condtions
  
     if(buttonContent=='Clear') //function for reset the values
    {
        resultvalue="";
        output.value = resultvalue;
    }
    else if(buttonContent=='=')
    {
        output.value=eval(resultvalue);
    }
    else
    {
        resultvalue+=buttonContent;
        output.value = resultvalue;
    }
   })

}
