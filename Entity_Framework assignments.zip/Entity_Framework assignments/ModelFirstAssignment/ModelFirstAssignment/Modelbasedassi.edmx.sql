
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, 2012 and Azure
-- --------------------------------------------------
-- Date Created: 08/18/2021 10:13:54
-- Generated from EDMX file: C:\Users\sai\source\repos\ModelFirstAssignment\ModelFirstAssignment\Modelbasedassi.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [MDFIRSTASSI];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------


-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Rooms'
CREATE TABLE [dbo].[Rooms] (
    [IdRoom] int IDENTITY(1,1) NOT NULL,
    [name] nvarchar(max)  NOT NULL,
    [description] nvarchar(max)  NOT NULL,
    [capacity] int  NOT NULL,
    [enabled] int  NOT NULL,
    [note] nvarchar(max)  NOT NULL,
    [smart] int  NOT NULL,
    [IdBuilding] int  NOT NULL,
    [floor] int  NOT NULL,
    [BuildingIdBuilding] int  NOT NULL
);
GO

-- Creating table 'Buildings'
CREATE TABLE [dbo].[Buildings] (
    [IdBuilding] int IDENTITY(1,1) NOT NULL,
    [FloorNumber] int  NOT NULL,
    [latitude] decimal(18,0)  NOT NULL,
    [longitude] decimal(18,0)  NOT NULL,
    [IdAddress] int  NOT NULL,
    [AddressIdAddress] int  NOT NULL
);
GO

-- Creating table 'Addresses'
CREATE TABLE [dbo].[Addresses] (
    [IdAddress] int IDENTITY(1,1) NOT NULL,
    [Address1] nvarchar(max)  NOT NULL,
    [Address2] nvarchar(max)  NOT NULL,
    [Address3] nvarchar(max)  NOT NULL,
    [PostalCode] nvarchar(max)  NOT NULL,
    [IdCity] int  NOT NULL,
    [CityIdCity] int  NOT NULL
);
GO

-- Creating table 'Cities'
CREATE TABLE [dbo].[Cities] (
    [IdCity] int IDENTITY(1,1) NOT NULL,
    [City1] nvarchar(max)  NOT NULL,
    [IdCountry] int  NOT NULL,
    [CountryIdCountry] int  NOT NULL
);
GO

-- Creating table 'Countries'
CREATE TABLE [dbo].[Countries] (
    [IdCountry] int IDENTITY(1,1) NOT NULL,
    [Country1] nvarchar(max)  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [IdRoom] in table 'Rooms'
ALTER TABLE [dbo].[Rooms]
ADD CONSTRAINT [PK_Rooms]
    PRIMARY KEY CLUSTERED ([IdRoom] ASC);
GO

-- Creating primary key on [IdBuilding] in table 'Buildings'
ALTER TABLE [dbo].[Buildings]
ADD CONSTRAINT [PK_Buildings]
    PRIMARY KEY CLUSTERED ([IdBuilding] ASC);
GO

-- Creating primary key on [IdAddress] in table 'Addresses'
ALTER TABLE [dbo].[Addresses]
ADD CONSTRAINT [PK_Addresses]
    PRIMARY KEY CLUSTERED ([IdAddress] ASC);
GO

-- Creating primary key on [IdCity] in table 'Cities'
ALTER TABLE [dbo].[Cities]
ADD CONSTRAINT [PK_Cities]
    PRIMARY KEY CLUSTERED ([IdCity] ASC);
GO

-- Creating primary key on [IdCountry] in table 'Countries'
ALTER TABLE [dbo].[Countries]
ADD CONSTRAINT [PK_Countries]
    PRIMARY KEY CLUSTERED ([IdCountry] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [BuildingIdBuilding] in table 'Rooms'
ALTER TABLE [dbo].[Rooms]
ADD CONSTRAINT [FK_RoomBuilding]
    FOREIGN KEY ([BuildingIdBuilding])
    REFERENCES [dbo].[Buildings]
        ([IdBuilding])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_RoomBuilding'
CREATE INDEX [IX_FK_RoomBuilding]
ON [dbo].[Rooms]
    ([BuildingIdBuilding]);
GO

-- Creating foreign key on [AddressIdAddress] in table 'Buildings'
ALTER TABLE [dbo].[Buildings]
ADD CONSTRAINT [FK_BuildingAddress]
    FOREIGN KEY ([AddressIdAddress])
    REFERENCES [dbo].[Addresses]
        ([IdAddress])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_BuildingAddress'
CREATE INDEX [IX_FK_BuildingAddress]
ON [dbo].[Buildings]
    ([AddressIdAddress]);
GO

-- Creating foreign key on [CityIdCity] in table 'Addresses'
ALTER TABLE [dbo].[Addresses]
ADD CONSTRAINT [FK_AddressCity]
    FOREIGN KEY ([CityIdCity])
    REFERENCES [dbo].[Cities]
        ([IdCity])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_AddressCity'
CREATE INDEX [IX_FK_AddressCity]
ON [dbo].[Addresses]
    ([CityIdCity]);
GO

-- Creating foreign key on [CountryIdCountry] in table 'Cities'
ALTER TABLE [dbo].[Cities]
ADD CONSTRAINT [FK_CityCountry]
    FOREIGN KEY ([CountryIdCountry])
    REFERENCES [dbo].[Countries]
        ([IdCountry])
    ON DELETE NO ACTION ON UPDATE NO ACTION;
GO

-- Creating non-clustered index for FOREIGN KEY 'FK_CityCountry'
CREATE INDEX [IX_FK_CityCountry]
ON [dbo].[Cities]
    ([CountryIdCountry]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------